import React, { useEffect, useState } from 'react';

const DiaryForm = ({ onAdd, editingDiary }) => {
  const [text, setText] = useState('');
  const [emotion, setEmotion] = useState('😊');

  useEffect(() => {
    if (editingDiary) {
      setText(editingDiary.text || '');
      setEmotion(editingDiary.emotion || '😊');
    } else {
      setText('');
      setEmotion('😊');
    }
  }, [editingDiary]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const entry = {
      text,
      emotion,
      date: editingDiary?.date || new Date().toISOString()
    };
    if (editingDiary?.id !== undefined) entry.id = editingDiary.id;
    onAdd(entry);
    setText('');
    setEmotion('😊');
  };

  const emotions = [
    { emoji: "😊", label: "기쁨" },
    { emoji: "😢", label: "슬픔" },
    { emoji: "😠", label: "화남" },
    { emoji: "😨", label: "불안" },
    { emoji: "❤️", label: "사랑" },
    { emoji: "😎", label: "자신감" },
    { emoji: "😭", label: "눈물" },
    { emoji: "😴", label: "피곤함" },
    { emoji: "😳", label: "당황" },
    { emoji: "🤢", label: "혐오" },
    { emoji: "😍", label: "설렘" },
    { emoji: "😬", label: "불편함" },
    { emoji: "🤯", label: "혼란" },
    { emoji: "😇", label: "평온함" },
    { emoji: "🤔", label: "고민중" },
    { emoji: "🤗", label: "위로" },
    { emoji: "😶", label: "무감정" },
    { emoji: "🤬", label: "격노" }
  ];

  return (
    <form onSubmit={handleSubmit} style={{
      backgroundColor: '#fff8dc',
      padding: '1rem',
      borderRadius: '15px',
      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
      marginBottom: '1rem'
    }}>
      <h3>📝 오늘의 마음을 적어보세요</h3>
      <textarea
        rows="4"
        cols="50"
        placeholder="내용 입력"
        value={text}
        onChange={(e) => setText(e.target.value)}
        required
        style={{ width: '100%', fontSize: '16px', marginBottom: '0.5rem' }}
      />
      <div>
        <label>감정 선택: </label>
        <select value={emotion} onChange={(e) => setEmotion(e.target.value)} style={{ fontSize: '18px' }}>
          {emotions.map(({ emoji, label }) => (
            <option key={emoji} value={emoji}>{emoji} {label}</option>
          ))}
        </select>
      </div>
      <button type="submit" style={{
        backgroundColor: editingDiary ? '#4caf50' : '#2196f3',
        color: 'white',
        padding: '0.5rem 1rem',
        fontSize: '16px',
        marginTop: '0.5rem',
        border: 'none',
        borderRadius: '10px',
        cursor: 'pointer'
      }}>{editingDiary ? "✏️ 수정" : "💾 저장"}</button>
    </form>
  );
};

export default DiaryForm;